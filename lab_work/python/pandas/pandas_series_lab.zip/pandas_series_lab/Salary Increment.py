salary = [25000, 32000, 28000, 40000, 50000]
emp = ['A', 'B', 'C', 'D', 'E']

s = pd.Series(salary, index=emp)

# Increase 10% <30000
s[s < 30000] *= 1.10

# Decrease 5% >45000
s[s > 45000] *= 0.95

# Total expense
print(s.sum())

'''output:
A    27500.0
B    32000.0
C    30800.0
D    40000.0
E    47500.0
180300.0
'''
