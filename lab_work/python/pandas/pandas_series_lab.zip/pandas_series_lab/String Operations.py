names = ['anuj', 'rahul', 'sneha', 'kiran', 'amit']
s = pd.Series(names)

# Uppercase
print(s.str.upper())

# Names with 'a'
print(s[s.str.contains('a')])

# Replace
s = s.replace('anuj', 'Anuj Kumar')
print(s)

'''output:
0    ANUJ
1    RAHUL
2    SNEHA
3    KIRAN
4    AMIT
0    anuj
1    rahul
2    sneha
3    kiran
4    amit
0    Anuj Kumar
1        rahul
2        sneha
3        kiran
4        amit
dtype: object
'''
