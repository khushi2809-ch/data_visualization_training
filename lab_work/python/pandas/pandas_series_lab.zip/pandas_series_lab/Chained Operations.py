data = [5, None, 15, 25, None, 35, 45]
s = pd.Series(data)

result = (s.fillna(s.median())
            [lambda x: x > 20]
            .sort_values(ascending=False)
            .reset_index(drop=True))

print(result)

'''output:
0    45.0
1    35.0
2    25.0
dtype: float64
'''
