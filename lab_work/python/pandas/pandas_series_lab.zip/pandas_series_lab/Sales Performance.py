sales = [200, 450, 300, 150, 500, 700, 100]
days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']

s = pd.Series(sales, index=days)

# Best & worst
print("Best:", s.idxmax())
print("Worst:", s.idxmin())

# Total & average
print("Total:", s.sum())
print("Average:", s.mean())

# 20% bonus
s[s > 400] *= 1.20
print(s)

# Sort descending
print(s.sort_values(ascending=False))

'''output:
Best: Sat
Worst: Sun
Total: 2400
Average: 342.85714285714283
Mon    200.0
Tue    450.0
Wed    300.0
Thu    150.0
Fri    500.0
Sat    840.0
Sun    100.0
Sat    840.0
Fri    500.0
Tue    450.0
Wed    300.0
Mon    200.0
Thu    150.0
dtype: float64
'''
