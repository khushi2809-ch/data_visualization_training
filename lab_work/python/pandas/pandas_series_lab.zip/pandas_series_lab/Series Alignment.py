
s1 = pd.Series([10, 20, 30], index=['A', 'B', 'C'])
s2 = pd.Series([5, 15, 25], index=['B', 'C', 'D'])

# Add
result = s1 + s2
print(result)

# Replace NaN with 0
result = (s1.add(s2, fill_value=0))
print(result)

'''output:
A     NaN
B    25.0
C    55.0
D     NaN
A    10.0
B    25.0
C    55.0
D    25.0
dtype: float64
'''
