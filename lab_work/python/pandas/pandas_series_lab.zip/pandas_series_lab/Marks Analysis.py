import pandas as pd

marks = [45, 67, 89, 34, 90, 55, 72]
subjects = ['Math', 'Physics', 'Chemistry', 'English', 'CS', 'Biology', 'History']

s = pd.Series(marks, index=subjects)

# >70
print(s[s > 70])

# Replace <40 with "Fail"
s = s.astype(object)
s[s < 40] = "Fail"
print(s)

# Count above average
avg = pd.Series(marks).mean()
count = sum([m > avg for m in marks])
print(count)

'''output:
Physics    67
Chemistry    89
CS    90
dtype: int64
Math         45
Physics      67
Chemistry    89
English      Fail
CS           90
Biology      55
History      72
4
'''
