data = [10, None, 30, None, 50, 60, None]
s = pd.Series(data)

# Count before
print(s.isnull().sum())

# Fill with mean
s = s.fillna(s.mean())

# Count after
print(s.isnull().sum())

# Drop remaining
s = s.dropna()
print(s)

'''output:
3
0
0    10.0
1    37.5
2    30.0
3    37.5
4    50.0
5    60.0
dtype: float64
'''
