marks = [95, 82, 67, 58, 73, 49, 88]
students = ['S1','S2','S3','S4','S5','S6','S7']

s = pd.Series(marks, index=students)

def grade(x):
    if x >= 90:
        return 'A'
    elif x >= 75:
        return 'B'
    elif x >= 60:
        return 'C'
    else:
        return 'D'

grades = s.apply(grade)

print(grades.value_counts())

'''output:
B    2
C    2
A    1
D    2
dtype: int64
'''
