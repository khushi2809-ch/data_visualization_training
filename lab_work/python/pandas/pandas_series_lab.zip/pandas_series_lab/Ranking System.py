scores = [88, 92, 79, 93, 85]
players = ['P1','P2','P3','P4','P5']

s = pd.Series(scores, index=players)

# Ranking
rank = s.rank(ascending=False)
print(rank)

# Top 3
print(s.sort_values(ascending=False).head(3))

# Lowest score
print(s.idxmin())

'''output:
P1    4.0
P2    1.0
P3    5.0
P4    2.0
P5    3.0
P2    92
P4    93
P5    85
P3
P3
dtype: int64
'''
